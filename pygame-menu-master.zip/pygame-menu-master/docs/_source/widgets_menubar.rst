.. module:: pygame_menu.widgets.widget.menubar

=======
MenuBar
=======

.. autoclass:: pygame_menu.widgets.MenuBar
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: change, draw_after_if_selected, flip, get_value, reset_value, resize, rotate, scale, select, set_border, set_default_value, set_max_height, set_max_width, set_onchange, set_onselect, set_padding, set_selection_effect, set_value, value_changed
