.. module:: pygame_menu.widgets.widget.image

======
Image
======

.. autoclass:: pygame_menu.widgets.Image
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: apply, change, draw_after_if_selected, get_font_color_status, get_font_info, get_sound, get_title, get_value, reset_value, set_default_value, set_font, set_font_shadow, set_onchange, set_onreturn, set_sound, set_tab_size, set_title, set_value, update, update_font, value_changed
