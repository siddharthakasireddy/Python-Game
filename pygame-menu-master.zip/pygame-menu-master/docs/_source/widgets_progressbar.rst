.. module:: pygame_menu.widgets.widget.progressbar

===========
ProgressBar
===========

.. autoclass:: pygame_menu.widgets.ProgressBar
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: add_self_to_kwargs, apply, change, draw_after_if_selected, flip, get_sound, resize, rotate, scale, set_max_height, set_max_width, set_onchange, set_onreturn, set_sound
