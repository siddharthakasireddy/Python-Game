.. module:: pygame_menu.widgets.widget.colorinput

==========
ColorInput
==========

.. autoclass:: pygame_menu.widgets.ColorInput
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: draw_after_if_selected, resize, rotate, scale, set_max_height, set_max_width
