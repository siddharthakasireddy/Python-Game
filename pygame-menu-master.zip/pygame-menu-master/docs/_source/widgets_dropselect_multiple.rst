.. module:: pygame_menu.widgets.widget.dropselect_multiple

==================
DropSelectMultiple
==================

.. autoclass:: pygame_menu.widgets.DropSelectMultiple
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: flip, resize, rotate, scale, set_max_height, set_max_width
