=======
License
=======

.. include:: ../../LICENSE

The official license can be retrieved `here <https://opensource.org/licenses/MIT>`_.
