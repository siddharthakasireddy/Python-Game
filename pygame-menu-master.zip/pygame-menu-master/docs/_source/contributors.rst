============
Contributors
============

Core developers:

- `Pablo Pizarro R. <https://ppizarror.com>`_

Main contributors:

- `anxuae <https://github.com/anxuae>`_
- `eforgacs <https://github.com/eforgacs>`_

Other contributors:

- `apuly <https://github.com/apuly>`_
- `arpruss <https://github.com/arpruss>`_
- `asierrayk <https://github.com/asierrayk>`_
- `DA820 <https://github.com/DA820>`_
- `i96751414 <https://github.com/i96751414>`_
- `ironsmile <https://github.com/ironsmile>`_
- `jwllee <https://github.com/jwllee>`_
- `maditnerd <https://github.com/maditnerd>`_
- `MayuSakurai <https://github.com/MayuSakurai>`_
- `mrkprdo <https://github.com/mrkprdo>`_
- `notrurs <https://github.com/notrurs>`_
- `NullP01nt <https://github.com/NullP01nt>`_
- `PandaRoux8 <https://github.com/PandaRoux8>`_
- `Rifqi31 <https://github.com/rifqi31>`_
- `ThePeeps191 <https://github.com/ThePeeps191>`_
- `thisIsMikeKane <https://github.com/thisIsMikeKane>`_
- `vnmabus <https://github.com/vnmabus>`_
- `werdeil <https://github.com/werdeil>`_
- `zPaw <https://github.com/zPaw>`_
- `neilsimp1 <https://github.com/neilsimp1>`_

Ideas and contributions are always welcome. Any found bugs or enhancement
suggestions should be posted on the `GitHub project page <https://github.com/ppizarror/pygame-menu>`_.