:orphan:

.. module:: pygame_menu.widgets.core.widget

======
Widget
======

.. autoclass:: pygame_menu.widgets.core.widget.Widget
    :members:
