.. module:: pygame_menu.widgets.widget.label

=====
Label
=====

.. autoclass:: pygame_menu.widgets.Label
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: apply, change, draw_after_if_selected, get_sound, get_value, reset_value, set_default_value, set_onchange, set_onreturn, set_sound, set_value, update, value_changed
