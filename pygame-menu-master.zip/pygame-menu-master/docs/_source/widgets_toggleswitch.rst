.. module:: pygame_menu.widgets.widget.toggleswitch

============
ToggleSwitch
============

.. autoclass:: pygame_menu.widgets.ToggleSwitch
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: draw_after_if_selected, flip, resize, rotate, scale, set_max_height, set_max_width
