.. module:: pygame_menu.widgets.widget.scrollbar

=========
ScrollBar
=========

.. autoclass:: pygame_menu.widgets.ScrollBar
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: apply, background_inflate_to_selection_effect, draw_after_if_selected, flip, get_font_color_status, get_selected_time, get_selection_effect, resize, rotate, scale, select, set_font, set_font_shadow, set_max_height, set_max_width, set_onreturn, set_onselect, set_padding, set_selection_effect, set_title, update_font
