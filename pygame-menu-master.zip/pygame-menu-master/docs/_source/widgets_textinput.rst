.. module:: pygame_menu.widgets.widget.textinput

=========
TextInput
=========

.. autoclass:: pygame_menu.widgets.TextInput
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: draw_after_if_selected, resize, rotate, scale, set_max_height, set_max_width
