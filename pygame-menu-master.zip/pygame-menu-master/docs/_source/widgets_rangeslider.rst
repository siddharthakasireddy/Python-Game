.. module:: pygame_menu.widgets.widget.rangeslider

===========
RangeSlider
===========

.. autoclass:: pygame_menu.widgets.RangeSlider
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: flip, resize, rotate, scale, set_max_height, set_max_width
