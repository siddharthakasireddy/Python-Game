.. module:: pygame_menu.widgets.widget.selector

========
Selector
========

.. autoclass:: pygame_menu.widgets.Selector
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: draw_after_if_selected
