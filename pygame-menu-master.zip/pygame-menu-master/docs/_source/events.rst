:orphan:

.. module:: pygame_menu.events

======
Events
======

.. autoclass:: pygame_menu.events.MenuAction
    :members:
    :show-inheritance:
