.. module:: pygame_menu.widgets.widget.button

======
Button
======

.. autoclass:: pygame_menu.widgets.Button
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: change, draw_after_if_selected, get_value, reset_value, set_default_value, set_onchange, set_value, value_changed
