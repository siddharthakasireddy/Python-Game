.. module:: pygame_menu._scrollarea

==========
ScrollArea
==========

.. autoclass:: pygame_menu._scrollarea.ScrollArea
    :members:
