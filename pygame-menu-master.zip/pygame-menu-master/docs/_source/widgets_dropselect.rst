.. module:: pygame_menu.widgets.widget.dropselect

==========
DropSelect
==========

.. autoclass:: pygame_menu.widgets.DropSelect
    :members:
    :show-inheritance:
    :inherited-members:
    :exclude-members: flip, resize, rotate, scale, set_max_height, set_max_width
