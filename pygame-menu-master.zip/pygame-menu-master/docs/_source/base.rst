:orphan:

.. module:: pygame_menu._base

====
Base
====

.. autoclass:: pygame_menu._base.Base
    :members:
    :noindex:
