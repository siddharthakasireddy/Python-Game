:orphan:

.. module:: pygame_menu._widgetmanager

=============
WidgetManager
=============

.. autoclass:: pygame_menu._widgetmanager.WidgetManager
    :members:
    :noindex:
