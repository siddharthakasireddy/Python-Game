"""
pygame-menu
https://github.com/ppizarror/pygame-menu

TEST
This directory contains all project tests files.
"""
