"""
pygame-menu
https://github.com/ppizarror/pygame-menu

CORE
This module contains the widget core classes.
"""

from pygame_menu.widgets.core.widget import Widget
from pygame_menu.widgets.core.selection import Selection
